<script setup>
</script>

<template>
  <main class="min-h-screen flex flex-col items-center justify-center px-6 text-center">
    <h1 class="text-4xl md:text-5xl font-semibold text-slate-800 mb-4">
      La Biblia · RVR 1960
    </h1>
    <p class="text-lg text-slate-600 max-w-2xl mb-8">
      Un espacio claro y accesible para leer, estudiar y meditar en las Escrituras,
      centrado en Jesucristo.
    </p>
    <div class="flex gap-4">
      <button class="px-6 py-3 rounded-xl bg-slate-800 text-white hover:bg-slate-700 transition">
        Comenzar lectura
      </button>
      <button class="px-6 py-3 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 transition">
        Explorar evangelios
      </button>
    </div>
  </main>
</template>
